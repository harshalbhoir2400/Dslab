import socket
import threading
import time

HOST = '127.0.0.1'
PORT = 65432
NUM_CLIENTS = 3
client_times = {}
lock = threading.Lock()

def handle_client(conn, addr):
    client_time = float(conn.recv(1024).decode())
    print(f"Received time {client_time} from {addr}")
    with lock:
        client_times[addr] = (client_time, conn)  # Save the connection too

def send_adjustments():
    all_times = [time_val for time_val, _ in client_times.values()]
    coordinator_time = time.time()
    all_times.append(coordinator_time)

    average_time = sum(all_times) / len(all_times)
    print(f"Average time: {average_time:.2f}")

    for addr, (client_time, conn) in client_times.items():
        adjustment = average_time - client_time
        conn.send(str(adjustment).encode())
        conn.close()
        print(f"Sent adjustment {adjustment:.2f} to {addr}")

def main():
    print("Coordinator started. Waiting for client times...")
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind((HOST, PORT))
    server.listen(NUM_CLIENTS)

    threads = []
    for _ in range(NUM_CLIENTS):
        conn, addr = server.accept()
        thread = threading.Thread(target=handle_client, args=(conn, addr))
        thread.start()
        threads.append(thread)

    for t in threads:
        t.join()

    print("All clients responded. Sending adjustments...")
    send_adjustments()
    server.close()

if __name__ == '__main__':
    main()

if __name__ == '__main__':
    offsets = [2.0, -3.5, 1.2]  # Different offsets for each client
    threads = []

    for offset in offsets:
        t = threading.Thread(target=client_node, args=(offset,))
        t.start()
        threads.append(t)

    for t in threads:
        t.join()

