class RingAlgorithm:
    def __init__(self, processes):
        # Sort the processes to ensure we always have a consistent order in the ring
        self.processes = sorted(processes)
        self.ring = self.processes[:]
        self.coordinator = None

    def is_alive(self, process_id):
        # Simulate which processes are alive (you could customize this)
        return process_id in self.ring

    def hold_election(self, initiator):
        print(f"Process {initiator} starts election.")
        
        # The election message starts with the initiator
        election_list = [initiator]
        current_index = self.ring.index(initiator)

        # Start circulating the election message around the ring
        while True:
            # Move to the next process in the ring
            current_index = (current_index + 1) % len(self.ring)
            next_process = self.ring[current_index]

            # If we have circled back to the initiator, the election ends
            if next_process == initiator:
                break

            # Send the election message to the next process
            print(f"Election message from {election_list[-1]} to {next_process}")
            election_list.append(next_process)

        # After the election message has passed through all processes, determine the winner
        winner = max(election_list)
        self.coordinator = winner
        print(f"Process {winner} is elected as the new coordinator.")


# Example usage
processes = [1, 2, 4, 6]  # List of process IDs
ring = RingAlgorithm(processes)  # Create RingAlgorithm object
ring.hold_election(initiator=2)  # Process 2 initiates the election

