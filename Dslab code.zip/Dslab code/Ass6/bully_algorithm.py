class BullyAlgorithm:
    def __init__(self, processes, coordinator=None):
        # List of process IDs
        self.processes = processes
        # Set the coordinator to the highest process ID if not specified
        self.coordinator = coordinator or max(processes)

    def is_alive(self, process_id):
        # Simulate which processes are alive; you can customize this as needed
        return process_id in self.processes

    def hold_election(self, initiator):
        # Start the election initiated by the specified process
        print(f"Process {initiator} starts election.")
        higher_processes = [p for p in self.processes if p > initiator]

        # If no higher processes exist, the initiator becomes the coordinator
        if not higher_processes:
            self.coordinator = initiator
            print(f"Process {initiator} becomes the new coordinator.")
        else:
            # Otherwise, the initiator sends election messages to all higher processes
            for p in higher_processes:
                print(f"Process {initiator} sends election message to {p}.")

            # Filter the responses to check which higher processes are alive
            responses = [p for p in higher_processes if self.is_alive(p)]
            
            if responses:
                # If there are responses, the highest process will continue the election
                print(f"Process {initiator} gets responses from: {responses}")
                highest = max(responses)
                self.hold_election(highest)
            else:
                # If no responses, the initiator becomes the coordinator
                self.coordinator = initiator
                print(f"No higher processes responded. Process {initiator} becomes coordinator.")


# Example usage
processes = [1, 2, 3, 5, 6]  # List of processes
bully = BullyAlgorithm(processes)  # Create BullyAlgorithm object
bully.hold_election(initiator=3)  # Process 3 initiates the election

